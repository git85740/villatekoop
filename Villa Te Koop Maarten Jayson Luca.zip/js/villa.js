function meerInfo() {
    let dots = document.getElementById("dots");
    let moreText = document.getElementById("volledig");
    let btnText = document.getElementById("infoKnop");
  
    if (dots.style.display === "none") {
      dots.style.display = "inline";
      btnText.innerHTML = "Meer weergeven"; 
      moreText.style.display = "none";
    } else {
      dots.style.display = "none";
      btnText.innerHTML = "Minder weergeven"; 
      moreText.style.display = "inline";
    }
  }

  document.getElementById("v1").onclick = function(){
           
    let voornaam = document.getElementById("voornaam").value;
    let achternaam = document.getElementById("achternaam").value;
    let Prijs = document.getElementById("Prijs").value;
    if (Prijs <= 1850000) {
      alert("Bedrag moet hoger zijn dan €1.850.000");
    }
    else {
    document.getElementById("bied-output").innerHTML = voornaam + " " + achternaam + " biedt " + "€" + Prijs + ".-";
  }
    
}

  document.getElementById("v2").onclick = function(){
           
    let voornaam = document.getElementById("voornaam").value;
    let achternaam = document.getElementById("achternaam").value;
    let Prijs = document.getElementById("Prijs").value;
    if (Prijs <= 1487500) {
      alert("Bedrag moet hoger zijn dan €1.487.500");
    }
    else {
    document.getElementById("bied-output").innerHTML = voornaam + " " + achternaam + " biedt " + "€" + Prijs + ".-";
  }
    
}

  document.getElementById("v3").onclick = function(){
           
    let voornaam = document.getElementById("voornaam").value;
    let achternaam = document.getElementById("achternaam").value;
    let Prijs = document.getElementById("Prijs").value;
    if (Prijs <= 2595000) {
      alert("Bedrag moet hoger zijn dan €2.595.000");
    }
    else {
    document.getElementById("bied-output").innerHTML = voornaam + " " + achternaam + " biedt " + "€" + Prijs + ".-";
  }
    
}