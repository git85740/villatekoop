<?php

$name= $_POST["name"];
$Prijs= $_POST["Prijs"];


$query = " ('$name' , '$Prijs')";

echo "naam:". $name . "<br>";
echo "Prijs:". $Prijs . "<br>";
?>


